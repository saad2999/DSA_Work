struct Node
{
	int data;
	Node* left;
	Node* right;
};