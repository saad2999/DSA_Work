#pragma once
#pragma once
#include"LinkedList.h"
template<class Q>
class myQueue
{
	myLL<Q>queueObj;
	int size;
public:
	void enqueue(Q data)
	{
		queueObj.insertAtFront(data);
		size++
	}
	Q dequeue()
	{
		Q var = queueObj.deleteFromHead();
		size--;

		return var;
	}
	
	void display()
	{
		queueObj.display();
	}
	bool isempty()
	{
		if (queueObj.head == nullptr)
		{
			return true;
		}
		return false;
	}
	int getsize()
	{
		return size;
	}



};

