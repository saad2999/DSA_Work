#include<iostream>
template<class T>
struct Node
{
	T data;
	Node<T>* next;
};
template<class T>
class LinkedList
{
protected:
	Node<T>* head;
public:
	
	virtual void insertAtEnd(T) = 0;
	virtual T deleteFromHead() = 0;
	virtual bool isEmpty() = 0;
	virtual void display() = 0;
};
template<class T>

class myLL:public LinkedList<T>
{
protected:
	int size;
	LinkedList<T>::head;
	
	
	
public:
	myLL()
	{
		head = nullptr;
		
	}
	void insertAtFront(T data)
	{
		
		Node<T>* temp = new Node<T>();
		temp->data = data;
		temp->next = nullptr;

		if (head == nullptr)
		{
			head = temp;

		}
		else
		{
			temp->next = head;
			head = temp;

		}

	}
	void insertAtEnd(T data)
	{
	
		if (head == nullptr)
		{
			insertAtFront(data);

		}
		else
		{
			Node<T>* temp = new Node<T>;
			temp->data = data;
			temp->next = nullptr;
			Node<T>* move = head;
			while (move->next != nullptr)
			{
				move = move->next;

			}
			move->next = temp;

		}
	}
	T deleteFromHead()
	{
		T data = head->data;
		Node<T>* temp = head->next;
		head->next = nullptr;
		delete head;
		head = temp;
		
		return data;
	}
	bool isEmpty()
	{
		if (head == nullptr)
		{
			return true;
		}
		return false;
	}
	void display()
	{
		Node<T>* temp = head;
		while (temp != nullptr)
		{
			std::cout << temp->data << "\n";
			temp = temp->next;

		}
	}


};