#include<iostream>
#include"DoublyCircularLinklink.h"
using namespace std;
int main()
{
	DoublyCircularLinklink obj;
	obj.insertDataONhead(9);
	obj.insertDataONhead(8);
	obj.insertDataONhead(7);
	obj.insertDataONhead(6);
	obj.insertDataONhead(5);
	obj.insertDataONhead(4);
	obj.insertDataONhead(3);
	obj.insertDataONhead(2);
	obj.insertDataONhead(1);
	obj.printList();

	
}